/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=12x25 enemy enemy.png 
 * Time-stamp: Wednesday 04/03/2024, 03:51:09
 * 
 * Image Information
 * -----------------
 * enemy.png 12@25
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef ENEMY_H
#define ENEMY_H

extern const unsigned short enemy[300];
#define ENEMY_SIZE 600
#define ENEMY_LENGTH 300
#define ENEMY_WIDTH 12
#define ENEMY_HEIGHT 25

#endif


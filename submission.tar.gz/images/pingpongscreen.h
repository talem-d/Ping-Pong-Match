/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=240x160 pingpongscreen pingpongscreen.png 
 * Time-stamp: Wednesday 04/03/2024, 03:18:16
 * 
 * Image Information
 * -----------------
 * pingpongscreen.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef PINGPONGSCREEN_H
#define PINGPONGSCREEN_H

extern const unsigned short pingpongscreen[38400];
#define PINGPONGSCREEN_SIZE 76800
#define PINGPONGSCREEN_LENGTH 38400
#define PINGPONGSCREEN_WIDTH 240
#define PINGPONGSCREEN_HEIGHT 160

#endif


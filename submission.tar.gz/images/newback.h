/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=240x160 newback newback.png 
 * Time-stamp: Wednesday 04/03/2024, 03:49:53
 * 
 * Image Information
 * -----------------
 * newback.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef NEWBACK_H
#define NEWBACK_H

extern const unsigned short newback[38400];
#define NEWBACK_SIZE 76800
#define NEWBACK_LENGTH 38400
#define NEWBACK_WIDTH 240
#define NEWBACK_HEIGHT 160

#endif


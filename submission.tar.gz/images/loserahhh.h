/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=240x160 loserahhh loserahhh.png 
 * Time-stamp: Wednesday 04/03/2024, 03:09:56
 * 
 * Image Information
 * -----------------
 * loserahhh.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef LOSERAHHH_H
#define LOSERAHHH_H

extern const unsigned short loserahhh[38400];
#define LOSERAHHH_SIZE 76800
#define LOSERAHHH_LENGTH 38400
#define LOSERAHHH_WIDTH 240
#define LOSERAHHH_HEIGHT 160

#endif


/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=240x160 winnerahhh winnerahhh.png 
 * Time-stamp: Wednesday 04/03/2024, 03:09:31
 * 
 * Image Information
 * -----------------
 * winnerahhh.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef WINNERAHHH_H
#define WINNERAHHH_H

extern const unsigned short winnerahhh[38400];
#define WINNERAHHH_SIZE 76800
#define WINNERAHHH_LENGTH 38400
#define WINNERAHHH_WIDTH 240
#define WINNERAHHH_HEIGHT 160

#endif

